-- Run this once in Supabase -> SQL Editor (adds the 'delete my post' feature).

-- A woman deletes her own post. Returns the storage path so the app can delete the file too.
create or replace function public.delete_my_post(p_post_id uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v_me public.profiles; v_path text; v_owner uuid;
begin
  v_me := public._me();
  select owner_id, storage_path into v_owner, v_path from public.posts where id = p_post_id;
  if not found then raise exception 'Post not found.'; end if;
  if v_owner <> v_me.id then raise exception 'That is not your post.'; end if;
  delete from public.posts where id = p_post_id;
  return coalesce(v_path, '');
end $$;

revoke execute on function public.delete_my_post(uuid) from public, anon;
grant execute on function public.delete_my_post(uuid) to authenticated;
