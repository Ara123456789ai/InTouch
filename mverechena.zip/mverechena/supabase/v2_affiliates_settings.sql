-- =====================================================================
-- InTouch v2: admin-editable settings (Ecocash number), affiliate programme,
-- and the new app name in messages.
-- Run ONCE in Supabase -> SQL Editor, AFTER schema.sql. Safe to run again.
-- =====================================================================

-- ------------------------------------------------------------ settings

insert into public.app_settings (key, value) values
  ('ecocash_number', '0787310643'),
  ('affiliate_percent', '30')
on conflict (key) do nothing;

-- The app reads the public settings from here (never the ntfy topic).
create or replace function public.get_settings() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'ecocash_number',
      coalesce((select value from public.app_settings where key = 'ecocash_number'), '0787310643'),
    'affiliate_percent',
      coalesce((select nullif(value, '')::numeric from public.app_settings where key = 'affiliate_percent'), 30));
$$;

create or replace function public.admin_set_setting(p_key text, p_value text) returns void
language plpgsql security definer set search_path = public as $$
declare v text := trim(coalesce(p_value, ''));
begin
  perform public._admin();
  if p_key = 'ecocash_number' then
    v := regexp_replace(v, '[\s\-()]', '', 'g');
    if v !~ '^\+?[0-9]{9,13}$' then
      raise exception 'Enter a valid Ecocash number, e.g. 0787310643.';
    end if;
  elsif p_key = 'affiliate_percent' then
    if v !~ '^[0-9]{1,3}(\.[0-9]{1,2})?$' then
      raise exception 'Enter a percentage between 0 and 100.';
    end if;
    if v::numeric > 100 then
      raise exception 'Enter a percentage between 0 and 100.';
    end if;
  else
    raise exception 'Unknown setting.';
  end if;
  insert into public.app_settings (key, value) values (p_key, v)
  on conflict (key) do update set value = excluded.value;
end $$;

-- ----------------------------------------------------------- affiliates

alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check
  check (role in ('user', 'admin', 'affiliate'));
alter table public.profiles add column if not exists referred_by uuid
  references public.profiles(id) on delete set null;
alter table public.profiles add column if not exists referred_at timestamptz;
alter table public.profiles add column if not exists code_attempts int not null default 0;

create table if not exists public.affiliates (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  code text not null unique,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- One row per settled date for a referred woman. The rate is saved with the row,
-- so changing the percentage later never changes what was already earned.
create table if not exists public.affiliate_earnings (
  id uuid primary key default gen_random_uuid(),
  affiliate_id uuid not null references public.profiles(id),
  bid_id uuid not null unique references public.bids(id) on delete cascade,
  female_id uuid not null,
  fee numeric(10,2) not null,
  rate numeric(5,4) not null,
  amount numeric(10,2) not null,
  created_at timestamptz not null default now()
);
create index if not exists affiliate_earnings_aff_idx on public.affiliate_earnings (affiliate_id);

create table if not exists public.affiliate_claims (
  id uuid primary key default gen_random_uuid(),
  affiliate_id uuid not null references public.profiles(id),
  affiliate_name text not null,
  affiliate_phone text not null,
  amount numeric(10,2) not null check (amount > 0),
  status text not null default 'requested' check (status in ('requested', 'paid', 'rejected')),
  payout_txn text,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
create index if not exists affiliate_claims_aff_idx on public.affiliate_claims (affiliate_id, created_at desc);

alter table public.affiliates          enable row level security;
alter table public.affiliate_earnings  enable row level security;
alter table public.affiliate_claims    enable row level security;
-- No policies on purpose: these tables are only reachable through the functions below.
revoke all on public.affiliates, public.affiliate_earnings, public.affiliate_claims
  from anon, authenticated;

create or replace function public._make_affiliate_code() returns text
language plpgsql volatile set search_path = public as $$
declare
  chars text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  s text;
  i int;
begin
  loop
    s := 'IT-';
    for i in 1..6 loop
      s := s || substr(chars, 1 + floor(random() * length(chars))::int, 1);
    end loop;
    exit when not exists (select 1 from public.affiliates where code = s);
  end loop;
  return s;
end $$;

-- Admin turns an existing (new, unused) account into an affiliate and gets its code.
create or replace function public.admin_create_affiliate(p_username text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare t public.profiles; v_code text;
begin
  perform public._admin();
  select * into t from public.profiles where username = lower(trim(coalesce(p_username, '')));
  if not found then raise exception 'No account with that username. Ask them to sign up first.'; end if;
  if t.role = 'admin' then raise exception 'That is an admin account.'; end if;
  if t.role = 'affiliate' then raise exception 'That account is already an affiliate.'; end if;
  if exists (select 1 from public.bids where male_id = t.id or female_id = t.id)
     or exists (select 1 from public.posts where owner_id = t.id) then
    raise exception 'That account already has dating activity. Use a fresh account for the affiliate.';
  end if;
  v_code := public._make_affiliate_code();
  update public.profiles set role = 'affiliate', status = 'active' where id = t.id;
  insert into public.affiliates (user_id, code) values (t.id, v_code);
  perform public._notify(t.id, 'You are now an InTouch affiliate',
    format('Your affiliate code is %s. Open the app to see your dashboard.', v_code));
  return jsonb_build_object('code', v_code);
end $$;

create or replace function public.admin_regenerate_code(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  perform public._admin();
  if not exists (select 1 from public.affiliates where user_id = p_user) then
    raise exception 'Affiliate not found.';
  end if;
  v_code := public._make_affiliate_code();
  update public.affiliates set code = v_code where user_id = p_user;
  perform public._notify(p_user, 'New affiliate code', format('Your new code is %s. The old code no longer works.', v_code));
  return jsonb_build_object('code', v_code);
end $$;

-- Switch a code off (or back on). Women already signed up stay with the affiliate.
create or replace function public.admin_set_affiliate_active(p_user uuid, p_active boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._admin();
  update public.affiliates set active = coalesce(p_active, true) where user_id = p_user;
  if not found then raise exception 'Affiliate not found.'; end if;
end $$;

-- Activation: either the usual Ecocash transaction ID, or an affiliate code.
-- (Return type changed, so the old version is dropped first.)
drop function if exists public.submit_activation(text);
create function public.submit_activation(p_txn text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  r public.profiles;
  v_txn text := left(trim(coalesce(p_txn, '')), 40);
  v_norm text;
  v_aff uuid;
  v_aff_name text;
begin
  if auth.uid() is null then raise exception 'Please sign in.'; end if;
  select * into r from public.profiles where id = auth.uid() for update;
  if not found then raise exception 'Account not found.'; end if;
  if r.status <> 'pending' then raise exception 'Account is already active.'; end if;
  if length(v_txn) < 4 then raise exception 'Enter the Ecocash transaction ID or your affiliate code.'; end if;

  v_norm := upper(regexp_replace(v_txn, '[^A-Za-z0-9]', '', 'g'));

  -- Looks like an affiliate code (IT + 6 characters)?
  if v_norm ~ '^IT[A-Z0-9]{6}$' then
    if r.code_attempts >= 5 then
      raise exception 'Too many wrong codes. Please contact InTouch support.';
    end if;
    select a.user_id, p.username into v_aff, v_aff_name
      from public.affiliates a join public.profiles p on p.id = a.user_id
     where a.active and upper(regexp_replace(a.code, '[^A-Za-z0-9]', '', 'g')) = v_norm;
    if found then
      if r.sex <> 'female' then
        raise exception 'Affiliate codes are for women''s accounts. Please pay the $1 and enter your Ecocash transaction ID.';
      end if;
      update public.profiles
         set status = 'active', referred_by = v_aff, referred_at = now(),
             activation_txn = 'CODE ' || v_norm, activation_rejected = null,
             activation_submitted_at = now()
       where id = r.id;
      perform public._notify(r.id, 'Welcome to InTouch', 'Your affiliate code was accepted. Your account is active. Enjoy!');
      perform public._notify(v_aff, 'New sign-up with your code', format('@%s joined InTouch with your code.', r.username));
      perform public._notify_admins('Activated with affiliate code',
        format('@%s used code %s (affiliate @%s).', r.username, v_norm, v_aff_name));
      return jsonb_build_object('activated', true);
    end if;
    update public.profiles set code_attempts = code_attempts + 1 where id = r.id;
    return jsonb_build_object('activated', false, 'wrongCode', true,
                              'attemptsLeft', 5 - r.code_attempts - 1);
  end if;

  update public.profiles
     set activation_txn = v_txn, activation_rejected = null, activation_submitted_at = now()
   where id = r.id;
  perform public._notify_admins('Activation payment to check',
    format('@%s (%s) paid $1. Txn %s. Reference %s.', r.username, r.phone, v_txn, upper(r.username)));
  return jsonb_build_object('activated', false);
end $$;

-- Commission: when a date is settled ("paid"), the affiliate who signed up that woman
-- earns the current percentage of InTouch's fee on it.
create or replace function public.bids_affiliate_commission() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_aff uuid; v_pct numeric; v_amt numeric;
begin
  select referred_by into v_aff from public.profiles where id = new.female_id;
  if v_aff is null then return null; end if;
  select coalesce(nullif(value, '')::numeric, 30) into v_pct
    from public.app_settings where key = 'affiliate_percent';
  v_pct := coalesce(v_pct, 30);
  v_amt := round(new.fee * v_pct / 100, 2);
  if v_amt > 0 then
    insert into public.affiliate_earnings (affiliate_id, bid_id, female_id, fee, rate, amount)
    values (v_aff, new.id, new.female_id, new.fee, v_pct / 100, v_amt)
    on conflict (bid_id) do nothing;
    if found then
      perform public._notify(v_aff, 'Commission earned',
        format('%s earned from a completed date by @%s.', public._money(v_amt), new.female_name));
    end if;
  end if;
  return null;
end $$;

drop trigger if exists bids_commission on public.bids;
create trigger bids_commission
  after update of status on public.bids
  for each row
  when (new.status = 'paid' and old.status is distinct from 'paid')
  execute function public.bids_affiliate_commission();

-- Everything the affiliate dashboard shows, in one call.
create or replace function public.affiliate_dashboard() returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_me public.profiles; v_code text; v_active boolean; v_pct numeric;
  v_users jsonb; v_claims jsonb;
  v_earned numeric; v_paid numeric; v_req numeric; v_pending numeric;
begin
  v_me := public._me();
  if v_me.role <> 'affiliate' then raise exception 'Affiliates only.'; end if;
  select code, active into v_code, v_active from public.affiliates where user_id = v_me.id;
  select coalesce(nullif(value, '')::numeric, 30) into v_pct from public.app_settings where key = 'affiliate_percent';
  v_pct := coalesce(v_pct, 30);

  select coalesce(jsonb_agg(jsonb_build_object(
           'username', p.username, 'status', p.status, 'joined', p.referred_at,
           'dates', coalesce(e.n, 0), 'earned', coalesce(e.s, 0))
         order by p.referred_at desc), '[]'::jsonb)
    into v_users
    from public.profiles p
    left join (select female_id, count(*) n, sum(amount) s
                 from public.affiliate_earnings where affiliate_id = v_me.id
                group by female_id) e on e.female_id = p.id
   where p.referred_by = v_me.id and p.sex = 'female';

  select coalesce(sum(amount), 0) into v_earned from public.affiliate_earnings where affiliate_id = v_me.id;
  select coalesce(sum(amount), 0) into v_paid from public.affiliate_claims where affiliate_id = v_me.id and status = 'paid';
  select coalesce(sum(amount), 0) into v_req from public.affiliate_claims where affiliate_id = v_me.id and status = 'requested';
  select coalesce(sum(round(b.fee * v_pct / 100, 2)), 0) into v_pending
    from public.bids b join public.profiles f on f.id = b.female_id
   where f.referred_by = v_me.id and b.status = 'completed';

  select coalesce(jsonb_agg(jsonb_build_object(
           'amount', c.amount, 'status', c.status, 'created_at', c.created_at, 'paid_at', c.paid_at)
         order by c.created_at desc), '[]'::jsonb)
    into v_claims
    from (select * from public.affiliate_claims where affiliate_id = v_me.id
           order by created_at desc limit 20) c;

  return jsonb_build_object(
    'code', v_code, 'code_active', v_active, 'percent', v_pct,
    'users', v_users, 'claims', v_claims,
    'earned', v_earned, 'paid', v_paid, 'requested', v_req,
    'pending', v_pending, 'balance', v_earned - v_paid - v_req);
end $$;

create or replace function public.claim_affiliate_earnings() returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_me public.profiles; v_earned numeric; v_used numeric; v_bal numeric;
begin
  v_me := public._me();
  if v_me.role <> 'affiliate' then raise exception 'Affiliates only.'; end if;
  perform 1 from public.profiles where id = v_me.id for update;  -- one claim at a time
  if exists (select 1 from public.affiliate_claims where affiliate_id = v_me.id and status = 'requested') then
    raise exception 'You already have a claim waiting to be paid.';
  end if;
  select coalesce(sum(amount), 0) into v_earned from public.affiliate_earnings where affiliate_id = v_me.id;
  select coalesce(sum(amount), 0) into v_used from public.affiliate_claims
   where affiliate_id = v_me.id and status in ('requested', 'paid');
  v_bal := v_earned - v_used;
  if v_bal < 1 then raise exception 'You need at least $1.00 available to claim.'; end if;
  insert into public.affiliate_claims (affiliate_id, affiliate_name, affiliate_phone, amount)
  values (v_me.id, v_me.username, v_me.phone, v_bal);
  perform public._notify_admins('Affiliate claim',
    format('@%s claims %s. Pay to %s.', v_me.username, public._money(v_bal), v_me.phone));
  return jsonb_build_object('amount', v_bal);
end $$;

create or replace function public.admin_mark_claim_paid(p_claim_id uuid, p_txn text) returns void
language plpgsql security definer set search_path = public as $$
declare c public.affiliate_claims;
begin
  perform public._admin();
  select * into c from public.affiliate_claims where id = p_claim_id for update;
  if not found then raise exception 'Claim not found.'; end if;
  if c.status <> 'requested' then raise exception 'This claim is already settled.'; end if;
  update public.affiliate_claims
     set status = 'paid', payout_txn = left(coalesce(p_txn, ''), 40), paid_at = now()
   where id = c.id;
  perform public._notify(c.affiliate_id, 'Claim paid', format('%s was sent to your Ecocash.', public._money(c.amount)));
end $$;

create or replace function public.admin_reject_claim(p_claim_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare c public.affiliate_claims;
begin
  perform public._admin();
  select * into c from public.affiliate_claims where id = p_claim_id for update;
  if not found then raise exception 'Claim not found.'; end if;
  if c.status <> 'requested' then raise exception 'This claim is already settled.'; end if;
  update public.affiliate_claims set status = 'rejected' where id = c.id;
  perform public._notify(c.affiliate_id, 'Claim not paid',
    format('Your claim of %s was not paid. The amount is back in your balance. Contact InTouch support.', public._money(c.amount)));
end $$;

-- Admin overview: every affiliate with their totals, plus claims waiting to be paid.
create or replace function public.admin_affiliates_overview() returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_aff jsonb; v_claims jsonb;
begin
  perform public._admin();
  select coalesce(jsonb_agg(x order by x.created_at desc), '[]'::jsonb) into v_aff
  from (
    select a.user_id, p.username, p.phone, a.code, a.active, a.created_at,
           (select count(*) from public.profiles r where r.referred_by = a.user_id) as referred,
           (select count(*) from public.profiles r where r.referred_by = a.user_id and r.status = 'active') as referred_active,
           coalesce((select sum(amount) from public.affiliate_earnings e where e.affiliate_id = a.user_id), 0) as earned,
           coalesce((select sum(amount) from public.affiliate_claims c where c.affiliate_id = a.user_id and c.status = 'paid'), 0) as paid,
           coalesce((select sum(amount) from public.affiliate_earnings e where e.affiliate_id = a.user_id), 0)
             - coalesce((select sum(amount) from public.affiliate_claims c where c.affiliate_id = a.user_id and c.status in ('requested', 'paid')), 0) as balance
      from public.affiliates a join public.profiles p on p.id = a.user_id
  ) x;
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', c.id, 'affiliate_name', c.affiliate_name, 'affiliate_phone', c.affiliate_phone,
           'amount', c.amount, 'created_at', c.created_at) order by c.created_at), '[]'::jsonb)
    into v_claims
    from public.affiliate_claims c where c.status = 'requested';
  return jsonb_build_object('affiliates', v_aff, 'claims', v_claims);
end $$;

-- ---------------------------------------- messages with the new app name

create or replace function public.admin_activate_user(p_uid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._admin();
  update public.profiles set status = 'active' where id = p_uid and status = 'pending';
  if not found then raise exception 'Account not found or already active.'; end if;
  perform public._notify(p_uid, 'Welcome to InTouch', 'Your account is active. Enjoy!');
end $$;

create or replace function public.submit_keyword(p_bid_id uuid, p_keyword text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_me public.profiles; b public.bids; v_kw text;
begin
  v_me := public._me();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.male_id <> v_me.id then raise exception 'Not your bid.'; end if;
  if b.status <> 'details_shared' then raise exception 'This date is not ready for a keyword.'; end if;
  if b.keyword_attempts >= 5 then
    raise exception 'Too many wrong attempts. Please contact InTouch support.';
  end if;
  select keyword into v_kw from public.bid_private where bid_id = b.id;
  if v_kw is null then raise exception 'Keyword missing. Contact support.'; end if;

  if regexp_replace(upper(coalesce(p_keyword, '')), '[^A-Z0-9]', '', 'g')
       = regexp_replace(upper(v_kw), '[^A-Z0-9]', '', 'g') then
    update public.bids set status = 'completed', completed_at = now() where id = b.id;
    perform public._notify_admins('Keyword received - pay her',
      format('@%s entered the keyword for %s. Pay @%s %s (fee %s).',
             b.male_name, public._code(b.id), b.female_name,
             public._money(b.payout), public._money(b.fee)));
    perform public._notify(b.female_id, 'Keyword received',
      format('Your payout of %s is being sent to your Ecocash.', public._money(b.payout)));
    return jsonb_build_object('ok', true);
  end if;

  update public.bids set keyword_attempts = keyword_attempts + 1 where id = b.id;
  return jsonb_build_object('ok', false, 'attemptsLeft', 5 - b.keyword_attempts - 1);
end $$;

-- ------------------------------------------------------------- who can call what

revoke execute on function
  public._make_affiliate_code(),
  public.bids_affiliate_commission()
  from public, anon, authenticated;

revoke execute on function
  public.get_settings(),
  public.admin_set_setting(text, text),
  public.admin_create_affiliate(text),
  public.admin_regenerate_code(uuid),
  public.admin_set_affiliate_active(uuid, boolean),
  public.submit_activation(text),
  public.affiliate_dashboard(),
  public.claim_affiliate_earnings(),
  public.admin_mark_claim_paid(uuid, text),
  public.admin_reject_claim(uuid),
  public.admin_affiliates_overview(),
  public.admin_activate_user(uuid)
  from public, anon;

grant execute on function
  public.get_settings(),
  public.admin_set_setting(text, text),
  public.admin_create_affiliate(text),
  public.admin_regenerate_code(uuid),
  public.admin_set_affiliate_active(uuid, boolean),
  public.submit_activation(text),
  public.affiliate_dashboard(),
  public.claim_affiliate_earnings(),
  public.admin_mark_claim_paid(uuid, text),
  public.admin_reject_claim(uuid),
  public.admin_affiliates_overview(),
  public.admin_activate_user(uuid)
  to authenticated;
