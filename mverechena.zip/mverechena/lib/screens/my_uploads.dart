import 'package:flutter/material.dart';

import '../models.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';

/// Her own photos and videos, with a delete button for each.
class MyUploads extends StatelessWidget {
  final String uid;
  const MyUploads({super.key, required this.uid});

  Future<void> _delete(BuildContext context, Map<String, dynamic> p) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete this post?'),
        content: const Text(
            'It will be removed from the touchline for good. Bids already made stay in the bidder\'s history.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Keep')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Delete')),
        ],
      ),
    );
    if (yes != true) return;
    final ok = await guard(() async {
      final res = await Api.call('delete_my_post', {'p_post_id': p['id']});
      final path = '${res['value'] ?? ''}';
      if (path.isNotEmpty) {
        try {
          await sb.storage.from('posts').remove([path]);
        } catch (_) {/* the post is gone either way */}
      }
    });
    if (ok) toast('Post deleted.');
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('My uploads',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: Venus.wine)),
            const SizedBox(height: 6),
            Live(
              create: () => sb
                  .from('posts')
                  .stream(primaryKey: ['id'])
                  .eq('owner_id', uid)
                  .order('created_at', ascending: false),
              builder: (context, snap) {
                if (snap.hasError) return Text(errText(snap.error!));
                if (!snap.hasData) {
                  return const Padding(
                      padding: EdgeInsets.all(8),
                      child: Center(child: CircularProgressIndicator()));
                }
                final posts = snap.data!;
                if (posts.isEmpty) {
                  return const Text(
                      'Nothing uploaded yet. Tap the camera on the touchline to add a photo or video.',
                      style: TextStyle(fontSize: 13));
                }
                return Column(
                  children: [
                    for (final p in posts)
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            width: 56,
                            height: 56,
                            child: p['type'] == 'video'
                                ? Container(
                                    color: Venus.wine,
                                    child: const Icon(Icons.play_circle,
                                        color: Venus.rose))
                                : Image.network('${p['media_url']}',
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                        color: Venus.blush,
                                        child: const Icon(Icons.broken_image))),
                          ),
                        ),
                        title: Text(
                          '${p['caption'] ?? ''}'.isEmpty
                              ? (p['type'] == 'video' ? 'Video' : 'Photo')
                              : '${p['caption']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(
                          p['approved'] == true
                              ? 'Live \u2022 ${p['like_count'] ?? 0} likes \u2022 ${p['bid_count'] ?? 0} bids'
                              : 'Waiting for approval',
                          style: TextStyle(
                              fontSize: 12,
                              color: p['approved'] == true
                                  ? Venus.emerald
                                  : Venus.copper),
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline,
                              color: Colors.redAccent),
                          onPressed: () => _delete(context, p),
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
