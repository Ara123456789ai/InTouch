import 'package:flutter/material.dart';

import '../models.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';

/// Admin console: activation payments, escrow confirmations, payouts after the
/// keyword arrives, disputes and photo/video approval. Works in the Android app
/// and in a browser (web build).
class AdminScreen extends StatelessWidget {
  final String uid;
  final Map<String, dynamic> me;
  const AdminScreen({super.key, required this.uid, required this.me});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 8,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('InTouch admin'),
          actions: [
            NotificationsButton(uid: uid),
            IconButton(icon: const Icon(Icons.logout), onPressed: signOut),
          ],
          bottom: const TabBar(
            isScrollable: true,
            labelColor: Venus.pearl,
            unselectedLabelColor: Venus.rose,
            indicatorColor: Venus.copper,
            tabs: [
              Tab(text: 'Activations'),
              Tab(text: 'Escrow'),
              Tab(text: 'Payouts'),
              Tab(text: 'Disputes'),
              Tab(text: 'Posts'),
              Tab(text: 'Live posts'),
              Tab(text: 'Affiliates'),
              Tab(text: 'Settings'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _AdminList(
              create: () => sb
                  .from('profiles')
                  .stream(primaryKey: ['id'])
                  .eq('status', 'pending')
                  .order('created_at', ascending: false),
              empty: 'No accounts waiting for activation.',
              builder: _userTile,
            ),
            _AdminList(
              create: () => _bidsByStatus('escrow_submitted'),
              empty: 'No escrow payments to confirm.',
              builder: _escrowTile,
            ),
            _AdminList(
              create: () => _bidsByStatus('completed'),
              empty: 'No payouts due.',
              builder: _payoutTile,
            ),
            _AdminList(
              create: () => _bidsByStatus('disputed'),
              empty: 'No open disputes.',
              builder: _disputeTile,
            ),
            _AdminList(
              create: () => sb
                  .from('posts')
                  .stream(primaryKey: ['id'])
                  .eq('approved', false)
                  .order('created_at', ascending: false),
              empty: 'No posts waiting for approval.',
              builder: _postTile,
            ),
            _AdminList(
              create: () => sb
                  .from('posts')
                  .stream(primaryKey: ['id'])
                  .eq('approved', true)
                  .order('created_at', ascending: false)
                  .limit(100),
              empty: 'No live posts yet.',
              builder: _postTile,
            ),
            const _AffiliatesTab(),
            const _SettingsTab(),
          ],
        ),
      ),
    );
  }
}

Stream<Rows> _bidsByStatus(String status) => sb
    .from('bids')
    .stream(primaryKey: ['id'])
    .eq('status', status)
    .order('created_at', ascending: false);

class _AdminList extends StatelessWidget {
  final Stream<Rows> Function() create;
  final String empty;
  final Widget Function(BuildContext, Map<String, dynamic>) builder;
  const _AdminList({required this.create, required this.empty, required this.builder});

  @override
  Widget build(BuildContext context) {
    return Live(
      create: create,
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(
              child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text(errText(snap.error!), textAlign: TextAlign.center)));
        }
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!;
        if (docs.isEmpty) {
          return Center(child: Text(empty, style: const TextStyle(color: Venus.copper)));
        }
        return ListView(
          padding: const EdgeInsets.all(10),
          children: [for (final d in docs) builder(context, d)],
        );
      },
    );
  }
}

Widget _shell(List<Widget> children) => Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      ),
    );

Widget _title(String t) => Text(t,
    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Venus.wine));

Widget _info(String t) => Padding(
      padding: const EdgeInsets.only(top: 3),
      child: Text(t, style: const TextStyle(fontSize: 13)),
    );

Widget _phoneRow(String label, String phone) => Row(
      children: [
        Expanded(child: _info('$label: $phone')),
        IconButton(
            icon: const Icon(Icons.call, size: 20, color: Venus.emerald),
            onPressed: () => callPhone(phone)),
        IconButton(
            icon: const Icon(Icons.chat, size: 20, color: Venus.emerald),
            onPressed: () => openUrl('https://wa.me/${phone.replaceAll(RegExp(r'[^0-9]'), '')}')),
      ],
    );


/// Phones and dispute notes live in an admin-only document so the two sides of a
/// bid never see each other's numbers before escrow is confirmed.
Widget _withAdmin(String bidId, Widget Function(Map<String, dynamic> a) build) {
  return Live(
    create: () => sb.from('bid_admin').stream(primaryKey: ['bid_id']).eq('bid_id', bidId),
    builder: (context, snap) {
      final rows = snap.data;
      return build(rows == null || rows.isEmpty ? <String, dynamic>{} : rows.first);
    },
  );
}

Widget _actions(List<Widget> buttons) =>
    Padding(padding: const EdgeInsets.only(top: 10), child: Wrap(spacing: 8, runSpacing: 6, children: buttons));

Future<String?> _askText(BuildContext context, String title, {String hint = '', bool required = false}) {
  final c = TextEditingController();
  return showDialog<String>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        TextButton(
            onPressed: () {
              if (required && c.text.trim().isEmpty) return;
              Navigator.pop(context, c.text.trim());
            },
            child: const Text('OK')),
      ],
    ),
  );
}

// ------------------------------------------------------------------ tiles

Widget _userTile(BuildContext context, Map<String, dynamic> u) {
  final txn = (u['activation_txn'] ?? '').toString();
  final id = '${u['id']}';
  return _shell([
    _title('@${u['username']}  (${u['sex']})'),
    _phoneRow('Phone', '${u['phone']}'),
    _info('Reference to look for: ${'${u['username']}'.toUpperCase()}'),
    _info(txn.isEmpty ? 'No payment reference submitted yet.' : 'Ecocash txn ID: $txn'),
    _info('Signed up ${fmtTs(u['created_at'])}'),
    _actions([
      ElevatedButton(
        onPressed: () => guard(() => Api.call('admin_activate_user', {'p_uid': id})),
        child: const Text('Activate'),
      ),
      if (txn.isNotEmpty)
        OutlinedButton(
          onPressed: () => guard(() => Api.call('admin_reject_activation', {'p_uid': id})),
          child: const Text('Reject payment'),
        ),
    ]),
  ]);
}

Widget _escrowTile(BuildContext context, Map<String, dynamic> b) {
  final id = '${b['id']}';
  return _shell([
    _title('${money(numOf(b['amount']))}  \u2022  ${typeLabel('${b['type']}')}'),
    _info('Reference: ${bidCode(id)}   Txn ID: ${b['escrow_txn']}'),
    _info('Payer: @${b['male_name']}'),
    _withAdmin(id, (a) => _phoneRow('His phone', '${a['male_phone'] ?? ''}')),
    _info('Date with: @${b['female_name']}'),
    _actions([
      ElevatedButton(
        onPressed: () => guard(() => Api.call('admin_confirm_escrow', {'p_bid_id': id})),
        child: const Text('Funds received - confirm'),
      ),
      OutlinedButton(
        onPressed: () => guard(() => Api.call('admin_reject_escrow', {'p_bid_id': id})),
        child: const Text('Not received'),
      ),
    ]),
  ]);
}

Widget _payoutTile(BuildContext context, Map<String, dynamic> b) {
  final id = '${b['id']}';
  final amount = numOf(b['amount']);
  final fee = numOf(b['fee']);
  final payout = numOf(b['payout']);
  return _shell([
    _title('Pay ${money(payout)} to @${b['female_name']}'),
    _info('Bid ${money(amount)} - platform fee ${money(fee)}   Ref ${bidCode(id)}'),
    _withAdmin(id, (a) => _phoneRow('Her Ecocash/phone', '${a['female_phone'] ?? ''}')),
    _info('Keyword received ${fmtTs(b['completed_at'])} from @${b['male_name']}'),
    _actions([
      ElevatedButton(
        onPressed: () async {
          final ref = await _askText(context, 'Payout sent. Ecocash reference (optional)');
          if (ref == null) return;
          await guard(() => Api.call('admin_mark_paid', {'p_bid_id': id, 'p_payout_txn': ref}));
        },
        child: const Text('Mark as paid'),
      ),
    ]),
  ]);
}

Widget _disputeTile(BuildContext context, Map<String, dynamic> b) {
  final id = '${b['id']}';
  return _shell([
    _title('${money(numOf(b['amount']))}  \u2022  ${bidCode(id)}'),
    _withAdmin(id, (a) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _info('Reported by ${a['disputed_by']}: ${a['dispute_reason']}'),
            _info('Was at stage: ${a['prev_status']}'),
            _phoneRow('His phone', '${a['male_phone'] ?? ''}'),
            _phoneRow('Her phone', '${a['female_phone'] ?? ''}'),
          ],
        )),
    _actions([
      ElevatedButton(
        onPressed: () => guard(() =>
            Api.call('admin_resolve_dispute', {'p_bid_id': id, 'p_outcome': 'payout'})),
        child: const Text('Pay her'),
      ),
      OutlinedButton(
        onPressed: () => guard(() =>
            Api.call('admin_resolve_dispute', {'p_bid_id': id, 'p_outcome': 'refund'})),
        child: const Text('Refund him'),
      ),
    ]),
  ]);
}

Widget _postTile(BuildContext context, Map<String, dynamic> p) {
  final id = '${p['id']}';
  final isVideo = p['type'] == 'video';
  return _shell([
    _title('@${p['owner_name']}  (${isVideo ? 'video' : 'photo'}${p['approved'] == true ? ', live' : ''})'),
    if (!isVideo)
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.network('${p['media_url']}', height: 260, width: double.infinity, fit: BoxFit.cover),
        ),
      )
    else
      TextButton.icon(
        onPressed: () => openUrl('${p['media_url']}'),
        icon: const Icon(Icons.play_circle),
        label: const Text('Open video'),
      ),
    if ('${p['caption'] ?? ''}'.isNotEmpty) _info('"${p['caption']}"'),
    _actions([
      if (p['approved'] != true)
        ElevatedButton(
          onPressed: () => guard(() => Api.call('admin_moderate_post', {'p_post_id': id, 'p_action': 'approve'})),
          child: const Text('Approve'),
        ),
      OutlinedButton(
        onPressed: () => guard(() async {
          final path = '${p['storage_path'] ?? ''}';
          if (path.isNotEmpty) {
            try {
              await sb.storage.from('posts').remove([path]);
            } catch (_) {/* file already gone */}
          }
          await Api.call('admin_moderate_post', {'p_post_id': id, 'p_action': 'remove'});
        }),
        child: const Text('Remove'),
      ),
    ]),
  ]);
}


// ------------------------------------------------------------- affiliates

class _AffiliatesTab extends StatefulWidget {
  const _AffiliatesTab();

  @override
  State<_AffiliatesTab> createState() => _AffiliatesTabState();
}

class _AffiliatesTabState extends State<_AffiliatesTab> {
  late Future<Map<String, dynamic>> _data = Api.call('admin_affiliates_overview');
  final _name = TextEditingController();
  bool _busy = false;

  Future<void> _reload() async {
    final f = Api.call('admin_affiliates_overview');
    setState(() {
      _data = f;
    });
    try {
      await f;
    } catch (_) {}
  }

  Future<void> _create() async {
    final u = _name.text.trim().toLowerCase();
    if (u.isEmpty) {
      toast("Enter the affiliate's username.");
      return;
    }
    setState(() => _busy = true);
    Map<String, dynamic>? res;
    final ok = await guard(() async {
      res = await Api.call('admin_create_affiliate', {'p_username': u});
    });
    if (mounted) setState(() => _busy = false);
    if (ok) {
      _name.clear();
      toast('Affiliate created. Their code is ${res?['code']}.');
      await _reload();
    }
  }

  Future<void> _act(Future<void> Function() f) async {
    final ok = await guard(f);
    if (ok) await _reload();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _reload,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _data,
        builder: (context, snap) {
          if (snap.hasError) {
            return ListView(padding: const EdgeInsets.all(20), children: [
              Text(errText(snap.error!), textAlign: TextAlign.center),
              TextButton(onPressed: _reload, child: const Text('Try again')),
            ]);
          }
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final d = snap.data!;
          final affs = (d['affiliates'] as List? ?? [])
              .map((e) => Map<String, dynamic>.from(e as Map))
              .toList();
          final claims = (d['claims'] as List? ?? [])
              .map((e) => Map<String, dynamic>.from(e as Map))
              .toList();
          return ListView(
            padding: const EdgeInsets.all(10),
            children: [
              _shell([
                _title('Add an affiliate'),
                _info('1. The person signs up in the app (any details, no payment needed).\n'
                    '2. Type their username here. Their account becomes an affiliate account '
                    'and gets a code to share.'),
                const SizedBox(height: 8),
                TextField(
                  controller: _name,
                  autocorrect: false,
                  decoration: const InputDecoration(
                      labelText: 'Affiliate username', isDense: true),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: VenusButton(
                      label: 'Make affiliate & get code',
                      loading: _busy,
                      onPressed: _create),
                ),
              ]),
              if (claims.isNotEmpty) ...[
                const Padding(
                  padding: EdgeInsets.fromLTRB(6, 10, 6, 0),
                  child: Text('Claims to pay',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: Venus.wine)),
                ),
                for (final c in claims)
                  _shell([
                    _title('Pay ${money(numOf(c['amount']))} to @${c['affiliate_name']}'),
                    _phoneRow('Ecocash / phone', '${c['affiliate_phone']}'),
                    _info('Claimed ${fmtTs(c['created_at'])}'),
                    _actions([
                      ElevatedButton(
                        onPressed: () async {
                          final ref = await _askText(
                              context, 'Paid. Ecocash reference (optional)');
                          if (ref == null) return;
                          await _act(() => Api.call('admin_mark_claim_paid',
                              {'p_claim_id': c['id'], 'p_txn': ref}));
                        },
                        child: const Text('Mark as paid'),
                      ),
                      OutlinedButton(
                        onPressed: () => _act(() =>
                            Api.call('admin_reject_claim', {'p_claim_id': c['id']})),
                        child: const Text('Reject'),
                      ),
                    ]),
                  ]),
              ],
              Padding(
                padding: const EdgeInsets.fromLTRB(6, 10, 6, 0),
                child: Text('Affiliates (${affs.length})',
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Venus.wine)),
              ),
              if (affs.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('No affiliates yet.',
                      style: TextStyle(color: Venus.copper)),
                ),
              for (final a in affs)
                _shell([
                  _title('@${a['username']}${a['active'] == false ? '  (code off)' : ''}'),
                  CopyRow('Affiliate code', '${a['code']}'),
                  _info('Women signed up: ${a['referred']} (${a['referred_active']} active)'),
                  _info('Earned ${money(numOf(a['earned']))}  •  Paid ${money(numOf(a['paid']))}  '
                      '•  Available ${money(numOf(a['balance']))}'),
                  _phoneRow('Phone', '${a['phone']}'),
                  _actions([
                    OutlinedButton(
                      onPressed: () async {
                        final yes = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Make a new code?'),
                            content: const Text('The old code will stop working straight away.'),
                            actions: [
                              TextButton(
                                  onPressed: () => Navigator.pop(context, false),
                                  child: const Text('Cancel')),
                              TextButton(
                                  onPressed: () => Navigator.pop(context, true),
                                  child: const Text('New code')),
                            ],
                          ),
                        );
                        if (yes != true) return;
                        await _act(() async {
                          final r = await Api.call(
                              'admin_regenerate_code', {'p_user': a['user_id']});
                          toast('New code: ${r['code']}');
                        });
                      },
                      child: const Text('New code'),
                    ),
                    OutlinedButton(
                      onPressed: () => _act(() => Api.call(
                          'admin_set_affiliate_active',
                          {'p_user': a['user_id'], 'p_active': a['active'] == false})),
                      child: Text(a['active'] == false ? 'Switch code on' : 'Switch code off'),
                    ),
                  ]),
                ]),
              const SizedBox(height: 20),
            ],
          );
        },
      ),
    );
  }
}

// --------------------------------------------------------------- settings

class _SettingsTab extends StatefulWidget {
  const _SettingsTab();

  @override
  State<_SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<_SettingsTab> {
  final _number = TextEditingController();
  final _pct = TextEditingController();
  bool _loaded = false;
  String? _loadError;
  bool _savingNumber = false;
  bool _savingPct = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await Api.call('get_settings');
      final p = numOf(s['affiliate_percent']);
      _number.text = '${s['ecocash_number'] ?? ''}';
      _pct.text = p % 1 == 0 ? p.toInt().toString() : p.toString();
      if (mounted) setState(() => _loaded = true);
    } catch (e) {
      if (mounted) setState(() => _loadError = errText(e));
    }
  }

  Future<void> _save(String key, TextEditingController c, String done) async {
    final ok = await guard(() => Api.call('admin_set_setting', {'p_key': key, 'p_value': c.text}));
    if (ok) {
      toast(done);
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loadError != null) {
      return Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(_loadError!)));
    }
    if (!_loaded) return const Center(child: CircularProgressIndicator());
    return ListView(
      padding: const EdgeInsets.all(10),
      children: [
        _shell([
          _title('Ecocash number'),
          _info('Shown to everyone who pays: the sign-up activation screen and the escrow screen. '
              'A change applies straight away.'),
          const SizedBox(height: 8),
          TextField(
            controller: _number,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
                labelText: 'Ecocash number', prefixIcon: Icon(Icons.phone), isDense: true),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: VenusButton(
              label: 'Save number',
              loading: _savingNumber,
              onPressed: () async {
                setState(() => _savingNumber = true);
                await _save('ecocash_number', _number, 'Ecocash number updated.');
                if (mounted) setState(() => _savingNumber = false);
              },
            ),
          ),
        ]),
        _shell([
          _title('Affiliate commission'),
          _info("The share of InTouch's fee that an affiliate earns on every settled date of a "
              'woman they signed up. Applies to dates settled from now on; what is already '
              'earned keeps its old rate.'),
          const SizedBox(height: 8),
          TextField(
            controller: _pct,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
                labelText: 'Affiliate share (%)', suffixText: '%', isDense: true),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: VenusButton(
              label: 'Save percentage',
              loading: _savingPct,
              onPressed: () async {
                setState(() => _savingPct = true);
                await _save('affiliate_percent', _pct, 'Affiliate percentage updated.');
                if (mounted) setState(() => _savingPct = false);
              },
            ),
          ),
        ]),
      ],
    );
  }
}
