import 'package:flutter/material.dart';

import '../logo.dart';
import '../models.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';

/// Dashboard for marketing affiliates: their code, the women they signed up,
/// and what they can claim.
class AffiliateScreen extends StatefulWidget {
  final String uid;
  final Map<String, dynamic> me;
  const AffiliateScreen({super.key, required this.uid, required this.me});

  @override
  State<AffiliateScreen> createState() => _AffiliateScreenState();
}

class _AffiliateScreenState extends State<AffiliateScreen> {
  late Future<Map<String, dynamic>> _data = Api.call('affiliate_dashboard');
  bool _claiming = false;

  Future<void> _reload() async {
    final f = Api.call('affiliate_dashboard');
    setState(() {
      _data = f;
    });
    try {
      await f;
    } catch (_) {}
  }

  Future<void> _claim(double balance) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Claim your earnings?'),
        content: Text(
            'You are claiming ${money(balance)}. InTouch will send it to your Ecocash '
            'number (${widget.me['phone']}) and you will be notified when it is paid.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Not now')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Claim')),
        ],
      ),
    );
    if (yes != true) return;
    setState(() => _claiming = true);
    final ok = await guard(() => Api.call('claim_affiliate_earnings'));
    if (ok) toast('Claim sent. You will be paid on your Ecocash number.');
    if (mounted) setState(() => _claiming = false);
    await _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Affiliate'),
        actions: [
          NotificationsButton(uid: widget.uid),
          IconButton(icon: const Icon(Icons.logout), onPressed: signOut),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _reload,
        child: FutureBuilder<Map<String, dynamic>>(
          future: _data,
          builder: (context, snap) {
            if (snap.hasError) {
              return ListView(
                padding: const EdgeInsets.all(24),
                children: [
                  Text(errText(snap.error!), textAlign: TextAlign.center),
                  TextButton(onPressed: _reload, child: const Text('Try again')),
                ],
              );
            }
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            return _content(snap.data!);
          },
        ),
      ),
    );
  }

  Widget _content(Map<String, dynamic> d) {
    final percent = numOf(d['percent']);
    final balance = numOf(d['balance']);
    final users = (d['users'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
    final claims = (d['claims'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
    final codeOn = d['code_active'] != false;
    final canClaim = balance >= 1 && numOf(d['requested']) == 0;

    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Center(child: BrandHeader(logoSize: 70, dark: false)),
        const SizedBox(height: 10),
        // ---- the code
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Your affiliate code',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Venus.wine)),
                CopyRow('Code', '${d['code']}'),
                const SizedBox(height: 4),
                Text(
                  codeOn
                      ? 'Give this code to women you sign up. They type it in the Ecocash '
                          'transaction ID box when they register, and their account activates '
                          'straight away.'
                      : 'Your code is switched off right now, so new sign-ups cannot use it. '
                          'Contact InTouch.',
                  style: TextStyle(
                      fontSize: 12, color: codeOn ? Venus.copper : Colors.redAccent),
                ),
              ],
            ),
          ),
        ),
        // ---- money
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Available to claim',
                    style: TextStyle(fontSize: 13, color: Venus.copper)),
                Text(money(balance),
                    style: const TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        color: Venus.emerald)),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: VenusButton(
                    label: canClaim
                        ? 'Claim ${money(balance)}'
                        : (numOf(d['requested']) > 0
                            ? 'Claim waiting to be paid'
                            : 'Claim (from \$1.00)'),
                    icon: Icons.payments_outlined,
                    loading: _claiming,
                    onPressed: canClaim ? () => _claim(balance) : null,
                  ),
                ),
                const Divider(height: 24),
                _line('Total earned', money(numOf(d['earned']))),
                _line('Already paid to you', money(numOf(d['paid']))),
                if (numOf(d['requested']) > 0)
                  _line('Claim waiting to be paid', money(numOf(d['requested']))),
                if (numOf(d['pending']) > 0)
                  _line('Coming from dates not yet settled',
                      '~${money(numOf(d['pending']))}'),
                const SizedBox(height: 8),
                Text(
                  'You earn ${percent.toStringAsFixed(percent % 1 == 0 ? 0 : 1)}% of the '
                  'InTouch fee on every date completed by a woman you signed up. It becomes '
                  'claimable once the date is settled and the woman has been paid.',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ),
        // ---- women signed up
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Women you signed up (${users.length})',
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Venus.wine)),
                const SizedBox(height: 6),
                if (users.isEmpty)
                  const Text('Nobody yet. Share your code to get started.',
                      style: TextStyle(fontSize: 13))
                else
                  for (final u in users)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const CircleAvatar(
                        backgroundColor: Venus.blush,
                        child: Icon(Icons.person, color: Venus.wine),
                      ),
                      title: Text('@${u['username']}'),
                      subtitle: Text(
                          'Joined ${fmtTs(u['joined'], 'd MMM yyyy')}  •  '
                          '${u['dates']} completed ${numOf(u['dates']) == 1 ? 'date' : 'dates'}'),
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(money(numOf(u['earned'])),
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  color: Venus.emerald)),
                          Text(u['status'] == 'active' ? 'Active' : '${u['status']}',
                              style: const TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
              ],
            ),
          ),
        ),
        // ---- claims history
        if (claims.isNotEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Your claims',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: Venus.wine)),
                  const SizedBox(height: 6),
                  for (final c in claims)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      title: Text(money(numOf(c['amount']))),
                      subtitle: Text(fmtTs(c['created_at'], 'd MMM yyyy, HH:mm')),
                      trailing: StatusChip(
                        c['status'] == 'paid'
                            ? 'Paid'
                            : c['status'] == 'rejected'
                                ? 'Not paid'
                                : 'Waiting',
                        c['status'] == 'paid'
                            ? Venus.emerald
                            : c['status'] == 'rejected'
                                ? Colors.grey
                                : Venus.copper,
                      ),
                    ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 12),
        const Text('Pull down to refresh.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: Colors.black45)),
      ],
    );
  }

  Widget _line(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          children: [
            Expanded(child: Text(a, style: const TextStyle(fontSize: 13))),
            Text(b, style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      );
}
