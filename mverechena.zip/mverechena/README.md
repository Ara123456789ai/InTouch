# InTouch dating app

Men bid for dates, women set a minimum price, and the money sits in Ecocash escrow until
the date is confirmed by a keyword. Flutter app + **Supabase** (Auth, Postgres, Storage,
Realtime) built with GitHub Actions. No paid plan needed to start.

Platform fee: **10% of the accepted bid, or $1 if 10% is less than $1** (taken from her payout;
he pays exactly what he bid). Change it in `lib/config.dart` and `supabase/schema.sql`
(function `_fee_for`).

## How the flow works

| Step | Who | What happens |
|---|---|---|
| Sign up | user | username, phone, password, sex, 18+ box. Account is *pending*. |
| Activate | user + admin | User sends $1 to the Ecocash number with their username as reference and enters the transaction ID. Admin sees it under **Activations**, taps **Activate**. |
| Touchline | all | Vertical scroll of approved photos/videos. Men: like, bid, report. Women: like, report, upload. |
| Bid | him | Short time / full time + amount. Below her minimum = auto-declined (he is told "too low", never her number). |
| Accept | her | Bids at/above her minimum show Accept / Reject. Accepting -> *waiting for confirmation*. |
| Escrow | him + admin | He sees the Ecocash number, exact amount and a reference code, pays, and enters the transaction ID. Admin checks the money, taps **Funds received**. 24h to pay or the bid expires. |
| Details | her | *Confirmed*: she enters time, place and phone. He can now see them (and call / open the map). She is shown her keyword. |
| Keyword | him + admin | At the meet and greet she tells him the keyword; he types it into the app. Admin is alerted with the amount to pay her. |
| Payout | admin | Admin sends her Ecocash payout (bid minus fee), taps **Mark as paid**. |
| Problems | both | "Report a problem" freezes the money; admin resolves under **Disputes** (pay her or refund him). |

Phone numbers sit in an admin-only table; each side only sees the other's number after escrow is
confirmed and she has shared it.

## One-time setup

1. **Create the project**: supabase.com -> New project (free). Pick the region closest to
   Zimbabwe (Cape Town if offered). Save the database password somewhere safe.
2. **Turn off email confirmation**: Authentication -> Sign In / Providers -> Email ->
   switch **Confirm email** OFF -> Save. (Usernames are turned into hidden `@mverechena.app`
   addresses, so no email can ever be confirmed. If this stays ON, sign-up will fail.)
3. **Create the database**: SQL Editor -> New query -> paste all of `supabase/schema.sql` -> **Run**,
   then do the same with `supabase/v2_affiliates_settings.sql` (affiliates + editable settings).
   Each should end with "Success". (Notices about pg_cron / pg_net are fine; see below.)
   Already installed before v2? Just run `v2_affiliates_settings.sql` once.
4. **Copy your keys**: Project Settings -> API (also called Data API / API Keys). Copy the
   **Project URL** and the **anon / publishable key** into `lib/supabase_config.dart`.
   These two values are public by design. Never put the `service_role` / secret key in the app.
5. **Build the app**: push to GitHub and run the workflow (see below), install the APK.
6. **Make yourself admin**: sign up in the app with a plain username (not an email), then in
   Supabase -> SQL Editor run (with your username):
   ```sql
   update public.profiles set role = 'admin', status = 'active' where username = 'your_username';
   ```
   Sign out and in again: you land on the admin console.

## Affiliates (marketing helpers)

- **Make one**: the person signs up in the app (any details, no $1 needed). In the admin console open
  **Affiliates**, type their username and tap **Make affiliate & get code**. Their account becomes an
  affiliate account with a code like `IT-K7M2QX`. (It must be a fresh account with no dating activity.)
- **Their sign-ups**: a woman registering enters the affiliate code in the "Ecocash transaction ID or
  affiliate code" box and her account activates immediately, with no payment. Codes only work for women's
  accounts. After 5 wrong code-like entries an account is locked out of guessing (contact support / reset
  `code_attempts` on her `profiles` row).
- **Their dashboard**: their code, the women they signed up (username, joined date, dates completed,
  amount earned), what they can claim now, and a claims history. No phone numbers are shown to affiliates.
- **Commission**: when a date is settled (you tap **Mark as paid** on the woman's payout), the affiliate
  earns the affiliate percentage (default 30%) of InTouch's fee on that date. Example: a $50 bid has a $5
  fee, so the affiliate earns $1.50. The percentage in force that day is saved with the earning, so changing
  it later never changes what was already earned.
- **Claims**: the affiliate taps **Claim** (minimum $1.00, one claim at a time). You are alerted; the claim
  appears under **Affiliates -> Claims to pay** with their phone number. Pay them by Ecocash, then tap
  **Mark as paid**. **Reject** puts the money back in their balance.
- **Code controls**: **New code** replaces the code (the old one stops working); **Switch code off** blocks
  new sign-ups with it. Women already signed up stay with the affiliate either way.
- Sign-ups with a code skip the $1 activation payment, so settle that with your affiliates outside the app.

## Settings (admin console -> Settings)

- **Ecocash number**: change it any time. Everyone sees the new number straight away on the sign-up
  payment screen and the escrow screen.
- **Affiliate share (%)**: the percentage of InTouch's fee that affiliates earn (default 30).

## Phone alerts for admin (optional, free)

The app shows pop-ups and a bell while it is open. To also get a phone notification when something
needs you (activation, escrow payment, keyword received):

1. Install the **ntfy** app (ntfy.sh) on your phone and subscribe to a long random topic name,
   e.g. `mverechena-k39fj28dh4x7q` (the topic name works like a password, so make it long).
2. In Supabase SQL Editor run:
   ```sql
   update public.app_settings set value = 'mverechena-k39fj28dh4x7q' where key = 'ntfy_topic';
   ```
   Alerts include usernames and amounts, never phone numbers or keywords.
   If you skipped it, or `pg_net` was not enabled (Database -> Extensions), nothing breaks.

## Things to know

- **Free plan limits**: 1 GB file storage, 50 MB per upload, and projects that see no activity for a
  week are paused (you un-pause with one click). Photos are shrunk to 1600px; videos are capped at
  30 seconds. Upgrade to Pro when real users arrive.
- **Expiry**: unpaid accepted bids expire after 24h and untouched bids after 7 days, checked hourly by
  `pg_cron`. If it was not enabled (Database -> Extensions -> pg_cron), the bids simply stay open.
- **Escrow is manual**: it is only as safe as you checking the Ecocash SMS before tapping
  **Funds received**. When volume grows, move to a Paynow/Ecocash merchant integration.
- New uploads stay hidden until you approve them (**Posts** tab). Check for under-18s and stolen photos.
- Women delete their own photos/videos from **Profile -> My uploads**. As admin you can remove any live post under **Live posts**. If you installed before this feature existed, run `supabase/update_delete_posts.sql` once in the SQL Editor.
- Touchline reports are saved in the `reports` table (Table Editor).
- To suspend someone, set `status` = `suspended` on their `profiles` row.
- You are responsible for complying with Zimbabwean law (Cyber and Data Protection Act, consumer
  and payment rules) and Ecocash terms for holding customer money.

## Project map

```
lib/main.dart                 auth gate + routing (pending / admin / man / woman)
lib/supabase_config.dart      your Supabase URL + anon key
lib/screens/feed_screen.dart  touchline + bid sheet + upload
lib/screens/bid_card.dart     bid card, escrow sheet, keyword, date details
lib/screens/dashboards.dart   his bids (3 tabs), her offers + minimum prices
lib/screens/admin_screen.dart admin console (8 tabs incl. Affiliates + Settings)
lib/screens/affiliate_screen.dart affiliate dashboard
lib/screens/my_uploads.dart   her uploads with delete buttons
supabase/schema.sql           tables, security rules, all money/state logic, storage bucket
supabase/v2_affiliates_settings.sql  affiliates, commissions, claims, editable settings
.github/workflows/build.yml   builds the Android APK
```
